/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.glassfish.javaee7.batch.lab4;

import java.util.Date;
import javax.batch.api.listener.JobListener;
import javax.batch.runtime.context.JobContext;
import javax.inject.Inject;
import javax.inject.Named;

@Named
public class PayrollJobListener
    implements JobListener {

    @Inject
    JobContext jobContext;
    
    @Override
    public void beforeJob() throws Exception {
        System.out.println("** PayrollJobListener:: Job started at: " + (new Date()));
    }

    @Override
    public void afterJob() throws Exception {
        System.out.println("** PayrollJobListener:: Job completed at: " + (new Date())
            + "; exitStatus : " + jobContext.getExitStatus() + "; " + jobContext.getBatchStatus());
    }
    
    
}
