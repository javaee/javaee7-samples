/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.glassfish.javaee7.batch.lab4;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;
import javax.batch.operations.JobOperator;
import javax.batch.runtime.BatchRuntime;
import javax.batch.runtime.JobExecution;
import javax.batch.runtime.JobInstance;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author makannan
 */
@WebServlet(urlPatterns = {"/BatchJobSubmitter"})
public class BatchJobSubmitter extends HttpServlet {

    @EJB
    PayrollDataHolderBean payrollDataHolderBean;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter pw = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            pw.println("<!DOCTYPE html>");
            pw.println("<html>");
            pw.println("<head>");
            pw.println("<title>Servlet BatchJobSubmitter</title>");            
            pw.println("</head>");
            pw.println("<body>");
            
            HttpSession session = request.getSession(true);
            long executionId = -1;
            if (session.getAttribute("executionId") != null) {
                executionId = (Long) session.getAttribute("executionId");
            } 
            if (executionId != -1)
                pw.println("<h3> Most recent executionId: " + executionId + "</h2>");

            try {
                String command = request.getParameter("command");
                if ("calculatePayroll".equals(command)) {
                    executionId = submitJobFromXML("PayrollJob");
                    session.setAttribute("executionId", executionId);
                } else if ("add".equals(command)) {
                    String data = request.getParameter("addedData");
                    if (data.trim() != null && data.trim().length() > 0)
                        payrollDataHolderBean.addPayrollInputRecord(request.getParameter("addedData"));
                } else if ("delete".equals(command)) {
                    int index = Integer.valueOf(request.getParameter("deleteIndex"));
                    payrollDataHolderBean.removePayrollInputRecordAt(index);
                } else if ("restart".equals(command)) {
                    executionId = restartJob(executionId);
                    session.setAttribute("executionId", executionId);
                }

                pw.println("<table>");
                pw.println("<tr><td>");
                displayPayrollForm(pw);
                pw.println("</td><td>");
                displayProcessedPayrollRecords(pw);
                pw.println("</td></tr>");
                pw.println("</table>");
                
                displayJobDetails(pw, executionId);
            } catch (Exception ex) {
                ex.printStackTrace(pw);
                throw new ServletException(ex);
            }
            
            
            pw.println("</body>");
            pw.println("</html>");
        }
    }
    
    private void displayProcessedPayrollRecords(PrintWriter pw)
        throws Exception {

        pw.println("<form>");
        pw.println("Processed Payroll Records");
        pw.println("<table border = \"yes\"><tr><td>Employee ID</td><td>Salary</td>"
            + "<td>Social Security</td><td>Net</td></tr>");
        for (PayrollOutputRecord record :  payrollDataHolderBean.getPayrollOutputRecords()) {
                pw.println("<tr><td>" + record.getEmpId()+ "</td>"
                        + "<td>" + record.getSalary() + "</td>"
                        + "<td>" + record.getSocialSecurityTax()+ "</td>"
                        + "<td>" + record.getNet()+ "</td></tr>");    
        }
        
        pw.println("<td><input type=\"submit\" name=\"command\" value=\"calculatePayroll\"/></td>");
        pw.println("<td><input type=\"submit\" name=\"command\" value=\"refresh\"/></td></tr>");
        pw.println("</table>");
        pw.println("</form>");

    }
    private void displayPayrollForm(PrintWriter pw)
        throws Exception {
        
        pw.println("<form>");
        pw.println("<table border=\"yes\">");
        pw.println("Payroll Input Records");
        int index = 0;
        for (String data :  payrollDataHolderBean.getPayrollInputData()) {
            pw.println("<form>");
            pw.println("<tr><td>" + data + "</td>");    
            pw.println("<td><input type=\"submit\" name=\"command\" value=\"delete\"</td>");
            pw.println("<td><input type=\"hidden\" name=\"deleteIndex\" value=\"" + (index++) + "\"</td>"); 
            pw.println("</form>");
        }
        pw.println("<tr><td><input type=\"text\" name=\"addedData\"/></td>"); 
        pw.println("<td><input type=\"submit\" name=\"command\" value=\"add\"/></td></tr>");
        pw.println("</table>");
    }
    
    private long submitJobFromXML(String jobName)
            throws Exception {
        JobOperator jobOperator = BatchRuntime.getJobOperator();

        Properties props = new Properties();
        return jobOperator.start(jobName, props);
    }
    
    private long restartJob(long executionId)
            throws Exception {
        JobOperator jobOperator = BatchRuntime.getJobOperator();

        Properties props = new Properties();
        return jobOperator.restart(executionId, props);
    }
    
    private void displayJobDetails(PrintWriter pw, long executionId) {
        pw.println("<h2> Current executionId: " + executionId + "</h2>");
        pw.println("<table>");
        pw.println("<tr><td>Status of Submitted Jobs</td></tr>");
        pw.println("<table border=\"yes\">");
        pw.println("<tr><td>Job Name</td><td>Instance ID</td><td>Execution ID</td>"
                + "<td>Batch Status</td><td>Exit Status</td>"
                + "<td>Start Time Status</td><td>End Time</td>"
                    + "</tr>");

        JobOperator jobOperator = BatchRuntime.getJobOperator();
        try {
            for (JobInstance jobInstance : jobOperator.getJobInstances("PayrollJob", 0, Integer.MAX_VALUE-1)) {
                for (JobExecution jobExecution : jobOperator.getJobExecutions(jobInstance)) {
                    StringBuilder sb = new StringBuilder();
                    if (executionId == jobExecution.getExecutionId()) {
                        sb.append("<tr style=\"background-color: green;\">");
                    } else {
                        sb.append("<tr>");
                    }                    sb.append("<td>").append(jobExecution.getJobName()).append("</td>");
                    sb.append("<td>").append(jobInstance.getInstanceId()).append("</td>");
                    sb.append("<td>").append(jobExecution.getExecutionId()).append("</td>");
                    sb.append("<td>").append(jobExecution.getBatchStatus()).append("</td>");
                    sb.append("<td>").append(jobExecution.getExitStatus()).append("</td>");
                    sb.append("<td>").append(jobExecution.getStartTime()).append("</td>");
                    sb.append("<td>").append(jobExecution.getEndTime()).append("</td>");
                    if ("FAILED".equals(jobExecution.getExitStatus()) && jobExecution.getExecutionId() == executionId) {
                        sb.append("<form>");
                        sb.append("<td><input type=\"submit\" name=\"command\" value=\"restart\"/></td>");
                        sb.append("</form>");
                    }
                    pw.println(sb.toString());
                }
            }
        } catch (Exception ex) {
            pw.println(ex.toString());
            ex.printStackTrace();
        }
        pw.println("</table>");
        pw.println("</table>");
    }

    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
