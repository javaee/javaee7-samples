/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.glassfish.javaee7.batch.lab4;

import javax.batch.api.chunk.listener.ItemReadListener;
import javax.batch.runtime.context.JobContext;
import javax.batch.runtime.context.StepContext;
import javax.inject.Inject;
import javax.inject.Named;

@Named
public class PayrollInputRecordReadListener
    implements ItemReadListener {

    @Inject
    JobContext jobContext;
    
    @Inject
    StepContext stepContext;

    @Override
    public void beforeRead() throws Exception {
    }

    @Override
    public void afterRead(Object item) throws Exception {
    }

    @Override
    public void onReadError(Exception ex) throws Exception {
        System.out.println("\t** PayrollInputRecordReadListener:: onReadError : "
                + stepContext.getTransientUserData() + " - Step Name : "+stepContext.getStepName()+"; Exception: " + ex);
    }    
      
}
